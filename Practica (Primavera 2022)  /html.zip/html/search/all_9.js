var searchData=
[
  ['leer_5fcircuito_47',['leer_circuito',['../class_circuito.html#a11921b78d44f2502e2273a0774e7465a',1,'Circuito']]],
  ['leer_5fcjt_5fcategorias_48',['leer_cjt_categorias',['../class_cjt__categorias.html#ad50753079065203566f2c76a74789a64',1,'Cjt_categorias']]],
  ['leer_5fcjt_5fjugadores_49',['leer_cjt_jugadores',['../class_cjt__jugadores.html#af45ac42128b04baed85944bd4c643ced',1,'Cjt_jugadores']]],
  ['leer_5finscritos_50',['leer_inscritos',['../class_torneo.html#ab171ddb63db4ab98e08a946291293c69',1,'Torneo']]],
  ['leer_5fresultados_51',['leer_resultados',['../class_torneo.html#a397e57c1a8ab0cf82bda39a888bff5ed',1,'Torneo']]],
  ['listar_5fcategorias_52',['listar_categorias',['../class_cjt__categorias.html#af46e714ce19151568983bd3dc26ee0a9',1,'Cjt_categorias']]],
  ['listar_5fjugadores_53',['listar_jugadores',['../class_cjt__jugadores.html#a24317852ef9a837ea9f1ea0d58597147',1,'Cjt_jugadores']]],
  ['listar_5franking_54',['listar_ranking',['../class_cjt__jugadores.html#a965f2c0d40253c9989053d78bf026390',1,'Cjt_jugadores']]],
  ['listar_5ftorneos_55',['listar_torneos',['../class_circuito.html#a5cc89f34b4537cfbddcb3ea2b3a42718',1,'Circuito']]]
];
