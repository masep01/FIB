var searchData=
[
  ['torneo_87',['Torneo',['../class_torneo.html',1,'Torneo'],['../class_torneo.html#a7bf6d35a7ec8d0e13a0bed8deb8add3e',1,'Torneo::Torneo()'],['../class_torneo.html#a83f583185350607882fb72e0e7f53771',1,'Torneo::Torneo(int c)']]],
  ['torneo_2ecc_88',['Torneo.cc',['../_torneo_8cc.html',1,'']]],
  ['torneo_2ehh_89',['Torneo.hh',['../_torneo_8hh.html',1,'']]],
  ['torneo_5fjugado_90',['torneo_jugado',['../class_circuito.html#a913fb0a83a6796ff12861e4af68472b2',1,'Circuito::torneo_jugado()'],['../class_torneo.html#a2957ffbf379d0d8a3f0cc2f3b4ec49e8',1,'Torneo::torneo_jugado()']]]
];
