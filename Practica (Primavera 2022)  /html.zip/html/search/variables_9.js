var searchData=
[
  ['vcat_191',['vcat',['../class_cjt__categorias.html#a098dc67f40799cf8b76ada542aa99b49',1,'Cjt_categorias']]]
];
