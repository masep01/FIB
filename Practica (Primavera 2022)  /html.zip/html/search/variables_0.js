var searchData=
[
  ['categoria_164',['categoria',['../class_torneo.html#ad9bec7ef311a416138abb99f3a487b3e',1,'Torneo']]],
  ['cuadro_165',['cuadro',['../class_torneo.html#a3a5d4527faf599edcc3e0fd6869dd2a1',1,'Torneo']]]
];
