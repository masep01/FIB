var searchData=
[
  ['main_148',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['modificar_5fposicion_149',['modificar_posicion',['../class_jugador.html#a29a8b620936c6b233af7c0afe4face06',1,'Jugador']]]
];
