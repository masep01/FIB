var searchData=
[
  ['s_5fganados_80',['s_ganados',['../class_jugador.html#aeba00f6c33f4d213ce8e3f65cde66e5e',1,'Jugador']]],
  ['s_5fperdidos_81',['s_perdidos',['../class_jugador.html#a5279dd561d8dd4819345040623e09d69',1,'Jugador']]],
  ['sets_5fganados_82',['sets_ganados',['../struct_torneo_1_1_stats.html#ad133fb1d901f7ad94e8711eda121f2c3',1,'Torneo::Stats']]],
  ['sets_5fperdidos_83',['sets_perdidos',['../struct_torneo_1_1_stats.html#add75293c4212dbfad392123c451995ae',1,'Torneo::Stats']]],
  ['stats_84',['Stats',['../struct_torneo_1_1_stats.html',1,'Torneo']]],
  ['sumar_5fpuntos_85',['sumar_puntos',['../class_cjt__jugadores.html#a7d189e7b00147f67f825c75e0bf1846c',1,'Cjt_jugadores::sumar_puntos()'],['../class_jugador.html#ae65dd68699b66ffa63ceb6803dcafbf8',1,'Jugador::sumar_puntos()']]],
  ['sumar_5fstats_86',['sumar_stats',['../class_cjt__jugadores.html#a86f753504b318ea9de84648c0cf79d6c',1,'Cjt_jugadores::sumar_stats()'],['../class_jugador.html#a49583610ed80004485c2ae24e01638d3',1,'Jugador::sumar_stats()']]]
];
