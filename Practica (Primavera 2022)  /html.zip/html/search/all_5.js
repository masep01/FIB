var searchData=
[
  ['finalizar_5ftorneo_27',['finalizar_torneo',['../class_circuito.html#adb22b02016b42a956131894f6eac0bac',1,'Circuito::finalizar_torneo()'],['../class_torneo.html#a1ba9e463a4b7ab39cbc2cc2f172045e6',1,'Torneo::finalizar_torneo()']]],
  ['first_5ftime_28',['first_time',['../class_torneo.html#a999ed633620e3b7232ded14b02d63aca',1,'Torneo']]]
];
