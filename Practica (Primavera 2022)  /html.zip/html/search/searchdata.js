var indexSectionsWithContent =
{
  0: "abcdefgijlmnoprstv~",
  1: "cjst",
  2: "cjpt",
  3: "abcdefgijlmnoprst~",
  4: "cfijmnprsv",
  5: "im"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "typedefs"
};

