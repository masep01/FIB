var searchData=
[
  ['ordenar_5franking_69',['ordenar_ranking',['../class_cjt__jugadores.html#a61d4c0806dcd9973fe8da0af7d39d672',1,'Cjt_jugadores']]]
];
