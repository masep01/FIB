var searchData=
[
  ['j_5fganados_40',['j_ganados',['../class_jugador.html#aaa34f161fcc2449f1d7d0ba107cb9ce0',1,'Jugador']]],
  ['j_5fperdidos_41',['j_perdidos',['../class_jugador.html#a4450c1be6a3b35f507bfc87759afd17a',1,'Jugador']]],
  ['juegos_5fganados_42',['juegos_ganados',['../struct_torneo_1_1_stats.html#ae28c9c54742b61872454c0f253369d88',1,'Torneo::Stats']]],
  ['juegos_5fperdidos_43',['juegos_perdidos',['../struct_torneo_1_1_stats.html#a2b87092b44f0b664219570335cc35385',1,'Torneo::Stats']]],
  ['jugador_44',['Jugador',['../class_jugador.html',1,'Jugador'],['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador::Jugador()'],['../class_jugador.html#a111018e5347b1a3fddb3ed3f4b5b1fd9',1,'Jugador::Jugador(int pos)']]],
  ['jugador_2ecc_45',['Jugador.cc',['../_jugador_8cc.html',1,'']]],
  ['jugador_2ehh_46',['Jugador.hh',['../_jugador_8hh.html',1,'']]]
];
