var searchData=
[
  ['procesar_5fpartido_152',['procesar_partido',['../class_torneo.html#abfad21852f7214d9edc23e3dbf264efd',1,'Torneo']]],
  ['procesar_5franking_5frelativo_153',['procesar_ranking_relativo',['../class_torneo.html#a230055a6701dd85c64563661e2761b8f',1,'Torneo']]]
];
