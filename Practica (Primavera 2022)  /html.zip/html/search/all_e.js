var searchData=
[
  ['ranking_78',['ranking',['../class_cjt__jugadores.html#acbc7a1cf4f7cb9a282f6f69a8bb4942a',1,'Cjt_jugadores']]],
  ['restar_5fpuntos_5fultima_5fedicion_79',['restar_puntos_ultima_edicion',['../class_torneo.html#a50e87690ebe576e08d481b1bc35c96ee',1,'Torneo']]]
];
