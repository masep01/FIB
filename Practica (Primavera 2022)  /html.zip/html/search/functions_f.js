var searchData=
[
  ['sumar_5fpuntos_155',['sumar_puntos',['../class_cjt__jugadores.html#a7d189e7b00147f67f825c75e0bf1846c',1,'Cjt_jugadores::sumar_puntos()'],['../class_jugador.html#ae65dd68699b66ffa63ceb6803dcafbf8',1,'Jugador::sumar_puntos()']]],
  ['sumar_5fstats_156',['sumar_stats',['../class_cjt__jugadores.html#a86f753504b318ea9de84648c0cf79d6c',1,'Cjt_jugadores::sumar_stats()'],['../class_jugador.html#a49583610ed80004485c2ae24e01638d3',1,'Jugador::sumar_stats()']]]
];
