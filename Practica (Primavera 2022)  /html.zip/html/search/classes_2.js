var searchData=
[
  ['stats_101',['Stats',['../struct_torneo_1_1_stats.html',1,'Torneo']]]
];
