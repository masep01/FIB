var searchData=
[
  ['n_5finscritos_63',['n_inscritos',['../class_torneo.html#ad7234d0b68dd3b8494b1a8b3482dfd8a',1,'Torneo']]],
  ['n_5ftorneos_64',['n_torneos',['../class_jugador.html#afdc8b2607be6eb8e1ccd398fa651061d',1,'Jugador']]],
  ['niveles_65',['niveles',['../class_cjt__categorias.html#a8a135fb01e90984f0903de2e04e27a0f',1,'Cjt_categorias']]],
  ['nplayers_66',['nplayers',['../class_cjt__jugadores.html#af4b2a4e570f53a3cf63bea717b738cfe',1,'Cjt_jugadores']]],
  ['ntorneos_67',['ntorneos',['../class_circuito.html#a9ce714ebf7176294d87759b395ba72f9',1,'Circuito']]],
  ['nuevo_5ftorneo_68',['nuevo_torneo',['../class_circuito.html#a6bdf00795d2a7252ffb70bd00f5afff6',1,'Circuito']]]
];
