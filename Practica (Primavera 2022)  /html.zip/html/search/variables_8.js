var searchData=
[
  ['s_5fganados_187',['s_ganados',['../class_jugador.html#aeba00f6c33f4d213ce8e3f65cde66e5e',1,'Jugador']]],
  ['s_5fperdidos_188',['s_perdidos',['../class_jugador.html#a5279dd561d8dd4819345040623e09d69',1,'Jugador']]],
  ['sets_5fganados_189',['sets_ganados',['../struct_torneo_1_1_stats.html#ad133fb1d901f7ad94e8711eda121f2c3',1,'Torneo::Stats']]],
  ['sets_5fperdidos_190',['sets_perdidos',['../struct_torneo_1_1_stats.html#add75293c4212dbfad392123c451995ae',1,'Torneo::Stats']]]
];
