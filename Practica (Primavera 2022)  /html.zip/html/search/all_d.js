var searchData=
[
  ['p_5fganados_70',['p_ganados',['../class_jugador.html#ad18984ec1f937f017841593d95b3cc22',1,'Jugador::p_ganados()'],['../struct_torneo_1_1_stats.html#a3cad52eb75893ee3a6506660b1d97e4e',1,'Torneo::Stats::p_ganados()']]],
  ['p_5fperdidos_71',['p_perdidos',['../class_jugador.html#a8ce94914f409b218364addaa39085fb4',1,'Jugador::p_perdidos()'],['../struct_torneo_1_1_stats.html#a9672866e67ea73da9066dd34623af3d7',1,'Torneo::Stats::p_perdidos()']]],
  ['posicion_72',['posicion',['../class_jugador.html#a0c0f3be497388acec0e2c890dcd46850',1,'Jugador']]],
  ['procesar_5fpartido_73',['procesar_partido',['../class_torneo.html#abfad21852f7214d9edc23e3dbf264efd',1,'Torneo']]],
  ['procesar_5franking_5frelativo_74',['procesar_ranking_relativo',['../class_torneo.html#a230055a6701dd85c64563661e2761b8f',1,'Torneo']]],
  ['program_2ecc_75',['program.cc',['../program_8cc.html',1,'']]],
  ['pts_5fedicion_5fant_76',['pts_edicion_ant',['../class_torneo.html#ae4640e2a7a1bcd503d636f9f0ee926e0',1,'Torneo']]],
  ['puntos_77',['puntos',['../class_jugador.html#a4e264d857d5a3f1a68cbb13e4b88930f',1,'Jugador::puntos()'],['../struct_torneo_1_1_stats.html#a44f78ff4738de24ab808f6d7cfa8ebed',1,'Torneo::Stats::puntos()']]]
];
