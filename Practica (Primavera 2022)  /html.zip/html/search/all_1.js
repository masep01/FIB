var searchData=
[
  ['baja_5fjugador_1',['baja_jugador',['../class_circuito.html#a4611294403fd64ae74e3520052626624',1,'Circuito::baja_jugador()'],['../class_torneo.html#a2f356e53cf805cdd01cc6da93fd47044',1,'Torneo::baja_jugador()']]],
  ['baja_5ftorneo_2',['baja_torneo',['../class_circuito.html#a8ec7f7fef22a22ea49566ece6d69f84f',1,'Circuito']]]
];
