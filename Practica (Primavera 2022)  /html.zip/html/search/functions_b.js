var searchData=
[
  ['nuevo_5ftorneo_150',['nuevo_torneo',['../class_circuito.html#a6bdf00795d2a7252ffb70bd00f5afff6',1,'Circuito']]]
];
