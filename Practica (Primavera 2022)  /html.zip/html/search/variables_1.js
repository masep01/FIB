var searchData=
[
  ['first_5ftime_166',['first_time',['../class_torneo.html#a999ed633620e3b7232ded14b02d63aca',1,'Torneo']]]
];
