var searchData=
[
  ['imprimir_5fcuadro_5femparejamiento_135',['imprimir_cuadro_emparejamiento',['../class_torneo.html#a282d196b8b246410343133f7f07da3bc',1,'Torneo']]],
  ['imprimir_5fcuadro_5fresultados_136',['imprimir_cuadro_resultados',['../class_torneo.html#a014cc64eb23a783ebd043f7f88706c4c',1,'Torneo']]],
  ['iniciar_5ftorneo_137',['iniciar_torneo',['../class_circuito.html#a9f5b0a5cc52a80e06e76c8f7feaa9388',1,'Circuito::iniciar_torneo()'],['../class_torneo.html#a0bf5a199bc11243457da69841cd292fd',1,'Torneo::iniciar_torneo()']]]
];
