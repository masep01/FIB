var searchData=
[
  ['j_5fganados_168',['j_ganados',['../class_jugador.html#aaa34f161fcc2449f1d7d0ba107cb9ce0',1,'Jugador']]],
  ['j_5fperdidos_169',['j_perdidos',['../class_jugador.html#a4450c1be6a3b35f507bfc87759afd17a',1,'Jugador']]],
  ['juegos_5fganados_170',['juegos_ganados',['../struct_torneo_1_1_stats.html#ae28c9c54742b61872454c0f253369d88',1,'Torneo::Stats']]],
  ['juegos_5fperdidos_171',['juegos_perdidos',['../struct_torneo_1_1_stats.html#a2b87092b44f0b664219570335cc35385',1,'Torneo::Stats']]]
];
