var searchData=
[
  ['ranking_186',['ranking',['../class_cjt__jugadores.html#acbc7a1cf4f7cb9a282f6f69a8bb4942a',1,'Cjt_jugadores']]]
];
