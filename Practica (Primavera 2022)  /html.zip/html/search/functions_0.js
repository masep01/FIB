var searchData=
[
  ['anadir_5fjugador_114',['anadir_jugador',['../class_cjt__jugadores.html#a4b8fb49849d20a9160e7bc9c1d4fcee8',1,'Cjt_jugadores']]]
];
