var searchData=
[
  ['restar_5fpuntos_5fultima_5fedicion_154',['restar_puntos_ultima_edicion',['../class_torneo.html#a50e87690ebe576e08d481b1bc35c96ee',1,'Torneo']]]
];
