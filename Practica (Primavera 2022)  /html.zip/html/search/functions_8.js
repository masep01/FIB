var searchData=
[
  ['jugador_138',['Jugador',['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador::Jugador()'],['../class_jugador.html#a111018e5347b1a3fddb3ed3f4b5b1fd9',1,'Jugador::Jugador(int pos)']]]
];
