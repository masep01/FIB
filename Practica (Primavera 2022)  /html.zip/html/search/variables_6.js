var searchData=
[
  ['p_5fganados_181',['p_ganados',['../class_jugador.html#ad18984ec1f937f017841593d95b3cc22',1,'Jugador::p_ganados()'],['../struct_torneo_1_1_stats.html#a3cad52eb75893ee3a6506660b1d97e4e',1,'Torneo::Stats::p_ganados()']]],
  ['p_5fperdidos_182',['p_perdidos',['../class_jugador.html#a8ce94914f409b218364addaa39085fb4',1,'Jugador::p_perdidos()'],['../struct_torneo_1_1_stats.html#a9672866e67ea73da9066dd34623af3d7',1,'Torneo::Stats::p_perdidos()']]],
  ['posicion_183',['posicion',['../class_jugador.html#a0c0f3be497388acec0e2c890dcd46850',1,'Jugador']]],
  ['pts_5fedicion_5fant_184',['pts_edicion_ant',['../class_torneo.html#ae4640e2a7a1bcd503d636f9f0ee926e0',1,'Torneo']]],
  ['puntos_185',['puntos',['../class_jugador.html#a4e264d857d5a3f1a68cbb13e4b88930f',1,'Jugador::puntos()'],['../struct_torneo_1_1_stats.html#a44f78ff4738de24ab808f6d7cfa8ebed',1,'Torneo::Stats::puntos()']]]
];
