var searchData=
[
  ['generar_5fcuadro_5femparejamiento_29',['generar_cuadro_emparejamiento',['../class_torneo.html#a883c2715446694442a1825d1d8117338',1,'Torneo']]]
];
