var searchData=
[
  ['inscritos_167',['inscritos',['../class_torneo.html#ab9e28935a3a78d35b566c4d8b0d68337',1,'Torneo']]]
];
